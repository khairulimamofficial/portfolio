// // import './bootstrap';

// function toggleActiveClass() {
//     var button = document.getElementById("arrowButton");
//     button.classList.toggle("active-see-more");
//   }