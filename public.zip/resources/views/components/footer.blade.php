<footer>
    <div class="container">
        <div data-aos="fade-right">
            <p class="footer_top">These experiences showcase my commitment to excellence, innovation, and leveraging technology for transformative solutions.
            </p>
        </div>
        <div class="flex footer-wrapper">
            <p class="footer_bottom">Made by</p>
            <img src="img/logo/logo.png" alt="logo" width="80px">
            <p class="footer_bottom">using PHP Laravel</p>
        </div>
    </div>
</footer>